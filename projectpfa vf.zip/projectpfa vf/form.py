from tkinter import *
import tkinter as tk
from tkinter import ttk, messagebox
import mysql.connector
from PIL import Image, ImageTk
import pymysql, os
from tkinter import filedialog

 

class hom:
   
   def __init__(self, root):
      self.window = root
      self.window.geometry('1166x718')
      self.window.resizable(0, 0)
      self.window.state('zoomed')

      self.bg_frame = Image.open('images\\car1.jpg')
      photo = ImageTk.PhotoImage(self.bg_frame)
      self.bg_panel = Label(self.window, image=photo)
      self.bg_panel.image = photo
      self.bg_panel.pack(fill='both', expand='yes')

      def GetValue(event):
         e1.delete(0, END)
         e2.delete(0, END)
         e3.delete(0, END)
         e4.delete(0, END)
         e5.delete(0, END)
         row_id = listBox.selection()[0]
         select = listBox.set(row_id)
         e1.insert(0,select['id'])
         e2.insert(0,select['make'])
         e3.insert(0,select['model'])
         e4.insert(0,select['year'])
   
   #----------------------------------foction ajouter car-----------------------------------
      def Add():
         vid = e1.get()
         vmake = e2.get()
         vmodel = e3.get()
         vyear = e4.get()
         vid1 =e5.get()
         fb=open(filename,'rb')
         fb=fb.read()   
         mysqldb=mysql.connector.connect(host="localhost",user="root",password="",database="projectpfa")
         mycursor=mysqldb.cursor()
   
         try:
            sql = "INSERT INTO  car (id,make,model,year, user_id,IMAGE ) VALUES (%s, %s, %s, %s, %s,%s)"
            val = (vid,vmake,vmodel,vyear,vid1,fb)
            mycursor.execute(sql,val)
            mysqldb.commit()
            lastid = mycursor.lastrowid
            messagebox.showinfo("information", "voitur inserted successfully...")
            e1.delete(0, END)
            e2.delete(0, END)
            e3.delete(0, END)
            e4.delete(0, END)
            e5.delete(0, END)
            e1.focus_set()
         except Exception as e:
            print(e)
            mysqldb.rollback()
            mysqldb.close()
   
   #----------------------------------foction update car-----------------------------------
      def update():
         vid = e1.get()
         vmake = e2.get()
         vmodel = e3.get()
         vyear = e4.get()
         vid1=e5.get()
         mysqldb=mysql.connector.connect(host="localhost",user="root",password="",database="projectpfa")
         mycursor=mysqldb.cursor()
   
         try:
            sql = "update  car set id= %s,make= %s,model= %s,year= %s where user_id= %s"
            val = (vid,vmake,vmodel,vyear)
            mycursor.execute(sql, val)
            mysqldb.commit()
            lastid = mycursor.lastrowid
            messagebox.showinfo("information", "Record Updateddddd successfully...")
      
            e1.delete(0, END)
            e2.delete(0, END)
            e3.delete(0, END)
            e4.delete(0, END)
            e5.delete(0, END)
            e1.focus_set()
      
         except Exception as e:
      
            print(e)
            mysqldb.rollback()
            mysqldb.close()
   #----------------------------------foction delete car-----------------------------------
      def delete():
         vid = e5.get()
      
         mysqldb=mysql.connector.connect(host="localhost",user="root",password="",database="projectpfa")
         mycursor=mysqldb.cursor()
      
         try:
            sql = "delete from car where  user_id = %s"
            val = (vid,)
            mycursor.execute(sql, val)
            mysqldb.commit()
            lastid = mycursor.lastrowid
            messagebox.showinfo("information", "Record Deleteeeee successfully...")
      
            e1.delete(0, END)
            e2.delete(0, END)
            e3.delete(0, END)
            e4.delete(0, END)
            e5.delete(0, END)
            e1.focus_set()
      
         except Exception as e:
      
            print(e)
            mysqldb.rollback()
            mysqldb.close()
   #----------------------------------foction show car-----------------------------------
      def show():
            for item in listBox.get_children():
                listBox.delete(item)
            vid=e5.get()
            mysqldb = mysql.connector.connect(host="localhost", user="root", password="", database="projectpfa")
            mycursor = mysqldb.cursor()
            sql="SELECT id,make,model,year FROM car where user_id = %s"
            val = (vid,)
            mycursor.execute(sql, val)
            
            records = mycursor.fetchall()
            print(records)
      
            for i, (id,stname, course,fee) in enumerate(records, start=1):
                  listBox.insert("", "end", values=(id, stname, course, fee))
                  mysqldb.close()
      
      
      def upload_image():
            global filename,img
            f_types = [('Png files','* png'), ('Jpg Files','* jpg')]
            filename = filedialog.askopenfilename (filetypes=f_types)
            if(filename):
               img = Image.open(filename)
               img=img. resize( (100, 100))
               img = ImageTk. PhotoImage (img)
               Label(frame, image=img, width=250, height=200,bg="#FFFFFF",fg='#000000',).place(x=790, y=5)
                  
         
      
      
      frame = Frame(self.window, bg='#FFFFFF', width=1000, height=1000)
      frame.place(x=250, y=100)
      global e1
      global e2
      global e3
      global e4
   
      Label(frame, text="Car Management", fg="#000000", font=('Comic Sans MS', 60),bg="#FFFFFF").place(x=0, y=5 )
      
      Label(frame, text="Id    :", font=('yu gothic ui', 20 , "bold"), bg="#FFFFFF",
                             fg='#000000',
                             bd=5,
                             relief=FLAT).place(x=350, y=135)
      Label(frame, text="Make  :",font=('yu gothic ui', 20, "bold"), bg="#FFFFFF",
                             fg='#000000',
                             bd=5,
                             relief=FLAT).place(x=350, y=175)
      Label(frame, text="Model :",font=('yu gothic ui', 20, "bold"), bg="#FFFFFF",
                             fg='#000000',
                             bd=5,
                             relief=FLAT).place(x=350, y=215)
      Label(frame, text="Year  :",font=('yu gothic ui', 20, "bold"), bg="#FFFFFF",
                             fg='#000000',
                             bd=5,
                             relief=FLAT).place(x=350, y=255)
      Label(frame, text="Id_user :",font=('yu gothic ui', 20, "bold"), bg="#FFFFFF",
                             fg='#000000',
                             bd=5,
                             relief=FLAT).place(x=350, y=295)   
      e1 = Entry(frame,highlightthickness=0, relief=FLAT, bg="#FFFFFF", fg="#000000",
                                    font=("yu gothic ui ", 12, "bold"), insertbackground = '#000000')
      e1.place(x=480, y=150, width=270)
      e1_line = Canvas(frame, width=300, height=2.0, bg="#bdb9b1", highlightthickness=0)
      e1_line.place(x=480, y=174)
   
      e2 = Entry(frame,highlightthickness=0, relief=FLAT, bg="#FFFFFF", fg="#000000",
                                    font=("yu gothic ui ", 12, "bold"), insertbackground = '#000000')
      e2.place(x=480, y=190,width=270)
      e2_line = Canvas(frame, width=300, height=2.0, bg="#bdb9b1", highlightthickness=0)
      e2_line.place(x=480, y=214)

      e3 = Entry(frame,highlightthickness=0, relief=FLAT, bg="#FFFFFF", fg="#000000",
                                    font=("yu gothic ui ", 12, "bold"), insertbackground = '#000000')
      e3.place(x=480, y=230, width=270)
      e3_line = Canvas(frame, width=300, height=2.0, bg="#bdb9b1", highlightthickness=0)
      e3_line.place(x=480, y=254)
   
      e4 = Entry(frame,highlightthickness=0, relief=FLAT, bg="#FFFFFF", fg="#000000",
                                    font=("yu gothic ui ", 12, "bold"), insertbackground = '#000000')
      e4.place(x=480, y=270, width=270)
      e1_line = Canvas(frame, width=300, height=2.0, bg="#bdb9b1", highlightthickness=0)
      e1_line.place(x=480, y=294)

      e5 = Entry(frame,highlightthickness=0, relief=FLAT, bg="#FFFFFF", fg="#000000",
                                    font=("yu gothic ui ", 12, "bold"), insertbackground = '#000000')
      e5.place(x=480, y=310, width=270)
      e1_line = Canvas(frame, width=300, height=2.0, bg="#bdb9b1", highlightthickness=0)
      e1_line.place(x=480, y=334)
   
      Button(frame, text="Add",command = Add,height=1, width= 15,font=("times new roman",18, "bold"),bd=0,cursor="hand2",bg="#1E90FF",fg="#FFFFFF").place(x=0, y=150)
      Button(frame, text="Update",command = update,height=1, width= 15,font=("times new roman",18, "bold"),bd=0,cursor="hand2",bg="#1E90FF",fg="#FFFFFF").place(x=0, y=210)
      Button(frame, text="Delete",command = delete,height=1, width= 15,font=("times new roman",18, "bold"),bd=0,cursor="hand2",bg="#1E90FF",fg="#FFFFFF").place(x=0, y=270)
      Button(frame, text="Show all cars",command = show,height=1, width= 15,font=("times new roman",18, "bold"),bd=0,cursor="hand2",bg="#1E90FF",fg="#FFFFFF").place(x=0, y=330)
      Button(frame, text= '+image',command=upload_image,height=1, width= 5,font=("times new roman",18, "bold"),bd=0,cursor="hand2",bg="#1E90FF",fg="#FFFFFF").place(x=220, y=150)
    
      cols = ('id', 'make', 'model','year')
      listBox = ttk.Treeview(frame,  columns=cols, show='headings' )
     
      for col in cols:
         listBox.heading(col, text=col)
         listBox.grid(row=1, column=0, columnspan=2)
         listBox.place(x=30, y=500)

     
      
      listBox.bind('<Double-Button-1>',GetValue)


      
if __name__ == "__main__":
    root = Tk()
    obj = hom(root)
    root.mainloop()      
      