# User Credentials
host = 'localhost'
user = 'root'
password = ''
database = 'projectpfa'